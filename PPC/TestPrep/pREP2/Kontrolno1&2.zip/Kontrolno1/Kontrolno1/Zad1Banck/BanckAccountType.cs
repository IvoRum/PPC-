﻿namespace Kontrolno1;

public enum BanckAccountType
{
    currentCurrency,foreignCurrency
}
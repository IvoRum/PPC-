﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPC_Dom6.Zad1
{
    interface ICourtDimensions
    {
        public double Width
        {
            get;
            set;
        }
        public double Length
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPC_Dom6.Zad2
{
    public abstract class Demo
    {
        public abstract void Show();
        public abstract double Lice();
    }
}

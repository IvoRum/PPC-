﻿namespace Zad2ExpostImportData;

public class PDFImport : Iinport
{
    public void import(File file)
    {
        Console.WriteLine("Import PDF");
    }
}
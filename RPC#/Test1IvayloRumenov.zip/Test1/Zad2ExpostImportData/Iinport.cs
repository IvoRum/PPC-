﻿namespace Zad2ExpostImportData;

public interface Iinport
{
    public void import(File file);
}
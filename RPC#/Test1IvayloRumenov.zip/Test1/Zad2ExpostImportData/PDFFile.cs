﻿namespace Zad2ExpostImportData;

public class PDFFile:File
{
    
}
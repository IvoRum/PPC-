﻿namespace Zad2ExpostImportData;

public interface Iexport
{
    public File export(File file);
}
﻿namespace Zad2ExpostImportData;

public interface File
{
    
}
﻿namespace Zad3ImgDispley;

public interface IImage
{
    public void PrintImage();
}
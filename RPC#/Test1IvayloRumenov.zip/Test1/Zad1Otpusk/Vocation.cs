﻿namespace Zad1Otpusk;

public abstract class Vocation
{
    public abstract void requestVecation(int daysOf);
}
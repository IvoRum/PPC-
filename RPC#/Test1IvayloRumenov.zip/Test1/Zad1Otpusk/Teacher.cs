﻿namespace Zad1Otpusk;

public class Teacher:WorkerDecorator
{
    public Teacher(Rukovoditel vovation) : base(vovation)
    {
    }
}
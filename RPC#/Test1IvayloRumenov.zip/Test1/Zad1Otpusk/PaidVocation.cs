﻿namespace Zad1Otpusk;

public class PaidVocation:Vocation
{
    public override void requestVecation(int daysOf)
    {
        Console.WriteLine("Vocation!!!!");
    }
}
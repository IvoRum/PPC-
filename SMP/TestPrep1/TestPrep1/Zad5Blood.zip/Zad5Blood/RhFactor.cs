﻿namespace Zad5Blood;

public enum RhFactor
{
    Positive,
    Negative
}
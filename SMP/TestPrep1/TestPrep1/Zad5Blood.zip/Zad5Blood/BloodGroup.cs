﻿namespace Zad5Blood;

public enum BloodGroup
{
    A,
    B,
    AB,
    O
}
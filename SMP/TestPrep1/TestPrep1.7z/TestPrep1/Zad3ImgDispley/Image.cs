﻿namespace Zad3ImgDispley;

public class Image:IImage
{
    private int lenght;
    private int hight;
    private string format;
    public void PrintImage()
    {
        throw new NotImplementedException();
    }
}
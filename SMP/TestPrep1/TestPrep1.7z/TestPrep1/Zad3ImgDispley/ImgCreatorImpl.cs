﻿namespace Zad3ImgDispley;

public class ImgCreatorImpl:ImgCreator
{
    public override Image ImageFactory(int lenght, int hight, string format)
    {
        throw new NotImplementedException();
    }
}
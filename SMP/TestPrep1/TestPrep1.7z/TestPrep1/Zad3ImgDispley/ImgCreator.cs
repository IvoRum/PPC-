﻿namespace Zad3ImgDispley;

public abstract class ImgCreator
{
    public abstract Image ImageFactory(int lenght, int hight, string format);
}
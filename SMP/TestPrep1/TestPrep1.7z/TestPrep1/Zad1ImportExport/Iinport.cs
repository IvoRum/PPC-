﻿namespace Zad1ImportExport;

public interface Iinport
{
    public void import(File file);
}
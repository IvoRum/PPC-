﻿namespace Zad1ImportExport;

public interface File
{
    
}
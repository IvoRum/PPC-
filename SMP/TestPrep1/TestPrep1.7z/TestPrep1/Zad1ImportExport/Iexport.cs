﻿namespace Zad1ImportExport;

public interface Iexport
{
    public File export(File file);
}
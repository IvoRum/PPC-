﻿namespace Zad1ImportExport;

public class PDFImport : Iinport
{
    public void import(File file)
    {
        //Iport the pdf
        
    }
}